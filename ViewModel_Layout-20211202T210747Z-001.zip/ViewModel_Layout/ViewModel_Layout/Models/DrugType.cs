﻿namespace ViewModel_Layout.Models
{
    public class DrugType
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
