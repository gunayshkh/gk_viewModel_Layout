﻿using ViewModel_Layout.Controllers.Models;

namespace ViewModel_Layout.Models
{
    public class PharmacyViewModel
    {
        public List<Drug> Drugs{ get; set; }
        public List<DrugType> DrugTypes { get; set; }
    }
}
