﻿namespace ViewModel_Layout.Controllers.Models
{
    public class Drug
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int DrugType { get; set; }
    }
}
