﻿using Microsoft.AspNetCore.Mvc;
using ViewModel_Layout.Controllers.Models;
using ViewModel_Layout.Models;

namespace ViewModel_Layout.Collections
{
    public class HomeController: Controller
    {
        public IActionResult Drug()    
        {
            List<Drug> Drugs = new List<Drug>();
            Drugs.Add(new Drug { Id = 1, Name = "Cardiomagnil", DrugType = 1 });
            Drugs.Add(new Drug { Id = 2, Name = "Paracetamol", DrugType = 2 });

            List<DrugType> DrugTypes = new List<DrugType>();
            DrugTypes.Add(new DrugType { Id = 1, Name = "Cardiology" });
            DrugTypes.Add(new DrugType { Id = 2, Name = "GeneralHealth" });

            PharmacyViewModel pharmacyViewModel = new PharmacyViewModel();
            pharmacyViewModel.Drugs = Drugs;    
            pharmacyViewModel.DrugTypes = DrugTypes;    

           return View(pharmacyViewModel);
        }

        public IActionResult DrugTypes()
        {
            List<DrugType> DrugTypes = new List<DrugType>();
            DrugTypes.Add(new DrugType { Id = 1, Name = "Cardiology" });
            DrugTypes.Add(new DrugType { Id = 2, Name = "GeneralHealth" });
            return View(DrugTypes);

        }
    }
}
